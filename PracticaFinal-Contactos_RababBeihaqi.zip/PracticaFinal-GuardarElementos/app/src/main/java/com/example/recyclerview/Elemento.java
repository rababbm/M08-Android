package com.example.recyclerview;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
@Entity
public class Elemento {
    @PrimaryKey(autoGenerate = true)
    int id;
    String titulo;
    String descripcion;
    String apellido;
    String tlf;
    int imageResource; // Agregar campo para el recurso de imagen
    public int imagenPorDefectoResource;

    public Elemento(String titulo, String apellido,String tlf, String descripcion, int imagenPorDefectoResource) {


        this.titulo = titulo;
        this.apellido= apellido;
        this.tlf = tlf;
        this.descripcion = descripcion;


        this.imageResource = imagenPorDefectoResource; // Asignar imagen por defecto
        this.imagenPorDefectoResource = imagenPorDefectoResource; // Asignar imagen por defecto
    }
}
